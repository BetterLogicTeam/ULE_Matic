import './Footer.css'

const Footer = () => {
    return ( 
        <div>
            <div className='footer '>
                  <p className='text-center  p-0 my-1'>Copyright © wirenft 2022. All right reserved.</p>
            </div>
        </div>
     );
}
 
export default Footer;