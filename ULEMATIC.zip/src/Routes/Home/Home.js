import {Dashboard} from '../../Containers'

const Home = () => {
    return ( 
        <div className='m-0 p-0'>
            <Dashboard />            
        </div>
     );
}
 
export default Home;